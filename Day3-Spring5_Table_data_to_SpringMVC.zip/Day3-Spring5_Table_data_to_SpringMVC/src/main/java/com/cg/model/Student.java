package com.cg.model;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	private int studId;
	private String studName;
	private String studLocation;
	private String studBranch;
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getStudLocation() {
		return studLocation;
	}
	public void setStudLocation(String studLocation) {
		this.studLocation = studLocation;
	}
	public String getStudBranch() {
		return studBranch;
	}
	public void setStudBranch(String studBranch) {
		this.studBranch = studBranch;
	}
	public Student(int studId, String studName, String studLocation, String studBranch) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.studLocation = studLocation;
		this.studBranch = studBranch;
	}
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studLocation=" + studLocation
				+ ", studBranch=" + studBranch + "]";
	}
	

}
