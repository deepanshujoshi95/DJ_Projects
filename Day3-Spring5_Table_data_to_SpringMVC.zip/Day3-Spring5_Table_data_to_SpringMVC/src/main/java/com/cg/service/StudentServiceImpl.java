package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.StudentDao;
import com.cg.model.Student;
@Service("studentService")
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDao studentDao;
	@Override
	@Transactional
	public List<Student> getStudentDetails() {
		return studentDao.getStudentDetails();
	}
	@Override
	public Student findStudentId(Integer studId) {
		return studentDao.findStudentId(studId);
	}
	@Override
	public void update(Student student) {
	
		studentDao.update(student);
		
	}

}
