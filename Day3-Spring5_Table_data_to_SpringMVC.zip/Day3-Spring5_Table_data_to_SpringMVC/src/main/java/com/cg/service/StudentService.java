package com.cg.service;

import java.util.List;

import com.cg.model.Student;

public interface StudentService {
	
	public List<Student> getStudentDetails();
	public Student findStudentId(Integer studId);
	public void update(Student student);

}
