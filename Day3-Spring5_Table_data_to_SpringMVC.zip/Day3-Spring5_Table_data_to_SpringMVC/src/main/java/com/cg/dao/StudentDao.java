package com.cg.dao;

import java.util.List;

import com.cg.model.Student;

public interface StudentDao {

	public List<Student> getStudentDetails();
	public Student findStudentId(Integer studId);
	public void update(Student student);
}
