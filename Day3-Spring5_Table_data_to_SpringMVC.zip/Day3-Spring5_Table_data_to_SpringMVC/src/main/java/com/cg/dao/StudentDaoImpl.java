package com.cg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Student;


@Repository("studentDao")
public class StudentDaoImpl implements StudentDao {

	@PersistenceContext
	private EntityManager entityManager;
	@Override
	@Transactional
	public List<Student> getStudentDetails() {
		List<Student> students=entityManager.createQuery("from Student").getResultList();
		return students;
	}
	@Transactional
	@Override
	public Student findStudentId(Integer studId) {
		Student student = entityManager.find(Student.class, studId);
		return student;
		
	}
	@Transactional
	@Override
	public void update(Student student) {
		if(student.getStudId()!=0)
			entityManager.merge(student);
		else
			entityManager.persist(student);
		
	}
	
	
}
