package com.cg.model;


import java.util.Date;

public class Pilot {

	private int pilotId;
	
	private String firstName;
	
	private String lastName;

	private Date dateofBirth;
	
	private Date dateofJoining;
	private Boolean certified;

	private double salary;

	private String pilotEmail;
	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateofBirth() {
		return dateofBirth;
	}
	public void setDateofBirth(Date dateofBirth) {
		this.dateofBirth = dateofBirth;
	}
	public Date getDateofJoining() {
		return dateofJoining;
	}
	public void setDateofJoining(Date dateofJoining) {
		this.dateofJoining = dateofJoining;
	}
	public Boolean getCertified() {
		return certified;
	}
	public void setCertified(Boolean certified) {
		this.certified = certified;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	public String getPilotEmail() {
		return pilotEmail;
	}
	public void setPilotEmail(String pilotEmail) {
		this.pilotEmail = pilotEmail;
	}

	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateofBirth="
				+ dateofBirth + ", dateofJoining=" + dateofJoining + ", certified=" + certified + ", salary=" + salary
				+ ", pilotEmail=" + pilotEmail + "]";
	}
	public Pilot(int pilotId, String firstName, String lastName, Date dateofBirth, Date dateofJoining,
			Boolean certified, double salary, String pilotEmail) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateofBirth = dateofBirth;
		this.dateofJoining = dateofJoining;
		this.certified = certified;
		this.salary = salary;
		this.pilotEmail = pilotEmail;
	}
	public Pilot() {
		super();
	}
	
	

	
}
