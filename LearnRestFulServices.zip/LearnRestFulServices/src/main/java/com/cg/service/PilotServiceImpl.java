package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.PilotDao;
import com.cg.model.Pilot;

@Service("pilotService")
public class PilotServiceImpl implements PilotService {
		@Autowired
		private PilotDao pilotDao;
		
		@Override
		public List<Pilot> getAllPilots() {
			
			return pilotDao.getAllPilots();
		}
		@Override
		public Pilot findPilot(Integer pilotId) {
			
			return pilotDao.findPilot(pilotId);
		}
		@Override
		public List<Pilot> deletePilot(Integer pilotId) {
			
			return pilotDao.deletePilot(pilotId);
		}
		@Override
		public List<Pilot> createPilots(Pilot pilot) {
			return pilotDao.createPilots(pilot);
		}
		
		
	}
