package com.cg.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Repository;

import com.cg.model.Pilot;

@Repository("pilotDao")
public class PilotDaoImpl implements PilotDao {

	private static AtomicInteger pilotId = new AtomicInteger(1000);
	
	public static List<Pilot> pilots =dummyPilot();
	

	private static List<Pilot> dummyPilot() {
		List<Pilot> pilots= new ArrayList<>();
		
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Tom","Jerry",new Date(),new Date(),true,25000, "tomandjerry@gmail.com"));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Jack","Jerry",new Date(),new Date(),true,35000, "jackandjerry@gmail.com"));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Som","Jerry",new Date(),new Date(),true,15000, "somandjerry@gmail.com"));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Luke","Jerry",new Date(),new Date(),true,75000, "lukeandjerry@gmail.com"));
		pilots.add(new Pilot(pilotId.incrementAndGet(),"Pro","Jerry",new Date(),new Date(),true,10000, "proandjerry@gmail.com"));
		return pilots;
	}
	

	@Override
	public List<Pilot> getAllPilots() {
	
		return pilots;
	}


	@Override
	public Pilot findPilot(Integer pilotId) {
	
		for (Pilot pilot : pilots) {
			if(pilot.getPilotId()==pilotId)
			{
				return pilot;
			}
		}
		return null;
	}


	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		boolean flag=false;
		Iterator<Pilot> pIter= pilots.iterator();
		while(pIter.hasNext())
		{
			if(pIter.next().getPilotId()==pilotId)
			{
				pIter.remove();
				flag=true;
				break;
			}
		}
		if(flag==true)
			return pilots;
		else
			return null;
	}


	@Override
	public List<Pilot> createPilots(Pilot pilot) {
		
	}


}
