package com.cg.dao;

import java.util.List;

import com.cg.model.Pilot;

public interface PilotDao {

	public List<Pilot> getAllPilots();

	public Pilot findPilot(Integer pilotId);

	public List<Pilot> deletePilot(Integer pilotId);

	public List<Pilot> createPilots(Pilot pilot);
	
}
