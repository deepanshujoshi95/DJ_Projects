package com.wallet.test;

import org.junit.Ignore;
import org.junit.Test;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.dao.CustomerDaoImpl;
import com.wallet.dao.ICustomerDAO;
import com.wallet.service.CustomerServiceImpl;
import com.wallet.service.ICustomerService;
import com.wallet.walletException.WalletException;

import junit.framework.TestCase;

public class CustomerDaoImplTest extends TestCase {

	ICustomerDAO idao = new CustomerDaoImpl();
	ICustomerService iservice = new CustomerServiceImpl();
	Account a = new Account();
	
	
	@Test
	public void testCreateAccount() {
		
		assertEquals(10, a.getAccMap().size());
		try {
			String id = idao.createAccount(new Customer("Diya","24","SRM Nagar","9584612342"), new Account("savings","25000"));
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		assertEquals(11, a.getAccMap().size());
	}

	
	@Test
	public void testShowBalance() {
		try {
			assertEquals("45000",idao.showBalance("HDFC111111224"));
		} catch (WalletException e) {
			System.err.println(e.getMessage());
		}
	}

	@Test
	public void testDeposit() {
		try {
			String bal = new String(idao.depositBalance("HDFC111111230", "5000"));
			assertEquals("45000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
	@Test
	public void testWithdraw() {
		try {
			String bal = new String(idao.withdrawBalance("HDFC111111231", "5000"));
			assertEquals("2000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public void testFundTransfer() {
		try {
			String bal = new String(idao.fundTransfer("HDFC111111226", "1000","HDFC111111228"));
			assertEquals("814000.0",bal);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public void testPrintTransaction() {
		try {
			assertEquals(0,idao.printingTransaction("HDFC111111222").size());
		} catch (WalletException e) {
			System.err.println(e.getMessage());
			}
	}

}

