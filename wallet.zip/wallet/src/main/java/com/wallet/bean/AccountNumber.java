package com.wallet.bean;

public class AccountNumber {
	
	private static String acc_no;

	public String getAcc_no()
	{
		return acc_no;
	}

	
	public void setAcc_no(String acc_no) 
	{
		this.acc_no = acc_no;
	}
	
	
	public AccountNumber() 
	{
		super();
		this.acc_no="HDFC"+System.currentTimeMillis();
	}

	
	
	public AccountNumber(String acc_no)
	{
		super();
		this.acc_no = acc_no;
	}
	
	
	

}
