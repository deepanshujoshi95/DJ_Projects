package com.wallet.bean;

import java.util.HashMap;
public class Account {

	private String acc_type;
	private String acc_balance;

		
	
	public String getAcc_type() {
		return acc_type;
	}
	
	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}
	
	public String getAcc_balance() {
		return acc_balance;
	}
	
	public void setAcc_balance(String acc_balance) {
		this.acc_balance = acc_balance;
	}

	public Account() {
		super();
	}


	public Account(String acc_type, String acc_balance) {
		super();
		this.acc_type = acc_type;
		this.acc_balance = acc_balance;
		
	}

	private static HashMap<String , Customer> acc_map= new HashMap<String ,Customer>();
	private static HashMap<String , Account> acc_details_map= new HashMap<String ,Account>();
	
	
	static 
	{
		acc_map.put("HDFC111111222", new Customer("Raj","21","ABC Nagar,Chennai","8955539811"));
		acc_map.put("HDFC111111223", new Customer("Rajesh","28","DEF Nagar,Bangalore","8955539812"));
		acc_map.put("HDFC111111224", new Customer("Ram","23","GHI Nagar,Rajasthan","8955539813"));
		acc_map.put("HDFC111111225", new Customer("Ramesh","27","MNO Nagar,Kanpur","8955539814"));
		acc_map.put("HDFC111111226", new Customer("Shyam","30","CRI Nagar,Goa","8955539815"));
		acc_map.put("HDFC111111227", new Customer("Shiv","51","ABC Nagar,Chennai","8955539816"));
		acc_map.put("HDFC111111228", new Customer("Deepesh","28","DEF Nagar,Bangalore","8955539817"));
		acc_map.put("HDFC111111229", new Customer("Deepanshu","23","GHI Nagar,Rajasthan","8955539818"));
		acc_map.put("HDFC111111230", new Customer("Paresh","32","MNO Nagar,Kanpur","8955539819"));
		acc_map.put("HDFC111111231", new Customer("Praveen","45","CRI Nagar,Goa","8955539820"));
	}
	
	static 
	{
		acc_details_map.put("HDFC111111222", new Account("Saving","85000"));
		acc_details_map.put("HDFC111111223", new Account("Current","15000"));
		acc_details_map.put("HDFC111111224", new Account("Current","45000"));
		acc_details_map.put("HDFC111111225", new Account("Saving","5000"));
		acc_details_map.put("HDFC111111226", new Account("Saving","815000"));
		acc_details_map.put("HDFC111111227", new Account("Current","425000"));
		acc_details_map.put("HDFC111111228", new Account("Current","985000"));
		acc_details_map.put("HDFC111111229", new Account("Saving","855000"));
		acc_details_map.put("HDFC111111230", new Account("Current","40000"));
		acc_details_map.put("HDFC111111231", new Account("Saving","7000"));
	}
	

	
	public  static HashMap<String , Customer> getAccMap()
	{
		return acc_map;
	}
	public static HashMap<String , Account> acc_details_map() 
	{
		return acc_details_map;
	}
	
	
}
