package com.wallet.bean;

public class TransactionNumber {
	
	private String transaction_number;

	public String getTransaction_number() {
		return transaction_number;
	}

	public void setTransaction_number(String transaction_number) {
		this.transaction_number = transaction_number;
	}

	public TransactionNumber(String transaction_number) {
		super();
		this.transaction_number = transaction_number;
	}

	public TransactionNumber() {
		super();
		this.transaction_number=" "+System.currentTimeMillis();
	}
		
	}

