package com.wallet.bean;

public class Customer {
	
	private String cust_name;
	private String cust_age;
	private String cust_address;
	private String phoneno;
	
	public String getCust_name() {
		return cust_name;
	}
	
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	
	public String getCust_age() {
		return cust_age;
	}
	
	public void setCust_age(String cust_age) {
		this.cust_age = cust_age;
	}
	
	public String getCust_address() {
		return cust_address;
	}
	
	public void setCust_address(String cust_address) {
		this.cust_address = cust_address;
	}
	
	public String getPhoneno() {
		return phoneno;
	}
	
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	
	public Customer() {
		super();
	}
	
	public Customer(String cust_name, String cust_age, String cust_address, String phoneno) {
		super();
		this.cust_name = cust_name;
		this.cust_age = cust_age;
		this.cust_address = cust_address;
		this.phoneno = phoneno;
	}
	
	
}
