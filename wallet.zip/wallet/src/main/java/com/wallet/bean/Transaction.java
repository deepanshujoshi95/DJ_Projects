package com.wallet.bean;

import java.time.LocalDate;
import java.util.HashMap;

public class Transaction {

private String status;
private String sender_account;
private String account;
private String receiver_account;
private String amount;
private LocalDate date;
private String transaction_type;

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getSender_account() {
	return sender_account;
}

public void setSender_account(String sender_account) {
	this.sender_account = sender_account;
}

public String getAccount() {
	return account;
}

public void setAccount(String account) {
	this.account = account;
}

public String getReceiver_account() {
	return receiver_account;
}

public void setReceiver_account(String receiver_account) {
	this.receiver_account = receiver_account;
}

public String getAmount() {
	return amount;
}

public void setAmount(String amount) {
	this.amount = amount;
}

public LocalDate getDate() {
	return date;
}

public void setDate(LocalDate date) {
	this.date = date;
}

public String getTransaction_type() {
	return transaction_type;
}

public void setTransaction_type(String transaction_type) {
	this.transaction_type = transaction_type;
}

public Transaction(String status, String account, String amount, LocalDate date, String transaction_type) {
	super();
	this.status = status;
	this.account = account;
	this.amount = amount;
	this.date = date;
	this.transaction_type = transaction_type;
	this.sender_account="";
	this.receiver_account="";
}

public Transaction(String status, String sender_account, String receiver_account, String amount, LocalDate date,
		String transaction_type) {
	super();
	this.status = status;
	this.sender_account = sender_account;
	this.receiver_account = receiver_account;
	this.amount = amount;
	this.date = date;
	this.transaction_type = transaction_type;
	this.account="";
}

public Transaction() {
	super();
}

private static HashMap<String, Transaction> transMap= new HashMap<String , Transaction>();

public static HashMap<String , Transaction > getTransactionMap()
{
	return  transMap;
}
}
