package com.wallet.dao;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.wallet.bean.Account;
import com.wallet.bean.AccountNumber;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.bean.TransactionNumber;
import com.wallet.walletException.WalletException;

public class CustomerDaoImpl implements ICustomerDAO{
	
	
	static HashMap<String, Customer> fetch_acc_map = Account.getAccMap();
	static HashMap<String , Account> fetch_acc_details = Account.acc_details_map();
	static HashMap<String, Transaction>feed_trans_details= Transaction.getTransactionMap();
	@Override
	public String createAccount(Customer cnew ,Account ac) throws WalletException {
		AccountNumber acc =new AccountNumber();
		fetch_acc_map.put(acc.getAcc_no(), cnew);
		fetch_acc_details.put(acc.getAcc_no(), ac);
		return acc.getAcc_no();
	}

	@Override
	public String showBalance(String acc_no) throws WalletException {
		 String balance=fetch_acc_details.get(acc_no).getAcc_balance();
		if(balance==null)
		{
			return null;
		}
	return balance;
	}

	@Override
	public String depositBalance(String dep_acc_no, String amount) throws WalletException {
		Account fetch_acc=fetch_acc_details.get(dep_acc_no);
		if(fetch_acc!=null)
		{
				String balance=fetch_acc.getAcc_balance();
				String newBal= Double.toString(Double.parseDouble(amount)+Double.parseDouble(balance));
				fetch_acc_details.put(dep_acc_no,new Account(fetch_acc.getAcc_type(),newBal));
				return newBal;
		}
		return null;
	}

	@Override
	public String withdrawBalance(String withdraw_acc_no, String amount) throws WalletException {
		Account fetch_acc=fetch_acc_details.get(withdraw_acc_no);
	
				String balance=fetch_acc.getAcc_balance();
				String newBal= Double.toString(Double.parseDouble(balance)-Double.parseDouble(amount));
				fetch_acc_details.put(withdraw_acc_no,new Account(fetch_acc.getAcc_type(),newBal));
				return newBal;
	}

	@Override
	public String fundTransfer(String origin_acc_no, String dest_acc_no, String amount) throws WalletException {
		Account fetch_origin_account=fetch_acc_details.get(origin_acc_no);
		Account fetch_dest_account=fetch_acc_details.get(dest_acc_no);
		 
		String balance_origin=fetch_origin_account.getAcc_balance();
		String balance_dest= fetch_dest_account.getAcc_balance();
		String new_origin_balance=Double.toString(Double.parseDouble(balance_origin)- Double.parseDouble(amount));
		String new_dest_balance=Double.toString(Double.parseDouble(balance_dest)+ Double.parseDouble(amount));
		fetch_acc_details.put(origin_acc_no, new Account(fetch_origin_account.getAcc_type(),new_origin_balance));
		fetch_acc_details.put(dest_acc_no, new Account(fetch_dest_account.getAcc_type(),new_dest_balance));
		return new_origin_balance;
	}
	

@Override
	public boolean checkAccountExist(String acc) throws WalletException {
		Account acct = fetch_acc_details.get(acc);
		if(acct!=null) {
			return true;
		}
		return false;
	}

@Override
public String updateDW(String status, String account, String amount, LocalDate date, String transaction_type)
		throws WalletException {
	TransactionNumber t= new TransactionNumber();
	feed_trans_details.put(t.getTransaction_number(), new Transaction(status,account,amount,date,transaction_type));
	return t.getTransaction_number();
}

@Override
public String transferTransaction(String status, String sender_account, String receiver_account, String amount,
		LocalDate date, String transaction_type) throws WalletException {
	
	TransactionNumber t= new TransactionNumber();
	feed_trans_details.put(t.getTransaction_number(), new Transaction(status,sender_account,receiver_account,amount,
			date,transaction_type));
	return t.getTransaction_number();
}

@Override
public HashMap<String, Transaction> printingTransaction(String accno) throws WalletException
{
	HashMap<String , Transaction> newMap= new HashMap<String , Transaction>();
	for(Map.Entry<String, Transaction> entry :feed_trans_details.entrySet())
	{
		if(entry.getValue().getAccount().equals(accno) ||entry.getValue().getReceiver_account().equals(accno) ||entry.getValue().getSender_account().equals(accno))
		{
			newMap.put(entry.getKey(),entry.getValue());
		}
	}
	return newMap;
}
}
