package com.wallet.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.walletException.WalletException;

public interface ICustomerService {
	
public boolean validateData(Customer cnew,Account ac) throws WalletException; 

public String createAccount(Customer cnew, Account ac) throws WalletException;

public String showBalance(String acc_no) throws WalletException;

public String depositBalance(String dep_acc_no,String amount) throws WalletException;

public String withdrawBalance(String withdraw_acc_no,String amount) throws WalletException;

public String fundTransfer(String origin_acc_no,String dest_acc_no,String amount) throws WalletException;

public boolean checkAccountExist(String acc) throws WalletException;

public String updateDW (String status, String account, String amount, LocalDate date, String transaction_type) throws WalletException;

public String transferTransaction(String status, String sender_account, String receiver_account, String amount, LocalDate date,
		String transaction_type) throws WalletException;

public HashMap<String,Transaction > printingTransaction(String accno) throws WalletException;
}
