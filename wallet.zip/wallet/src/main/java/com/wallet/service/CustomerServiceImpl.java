package com.wallet.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.dao.CustomerDaoImpl;
import com.wallet.dao.ICustomerDAO;
import com.wallet.walletException.WalletException;

public class CustomerServiceImpl implements ICustomerService {
	
	ICustomerDAO idao= new CustomerDaoImpl();

	@Override
	public boolean validateData(Customer cnew, Account ac) throws WalletException {
		if(validateName(cnew.getCust_name()) && validateAge(cnew.getCust_age()) && 
			validatePhoneNo(cnew.getPhoneno()) && validateAccType(ac.getAcc_type()) && validateInitBalance(ac.getAcc_balance()))
		{
					return true;
		}
			return false;
	}
	
	private boolean validateName(String name) throws WalletException
	{
		if(name==null || name.isEmpty())
		{
			throw new WalletException("Name cannot be Null or Empty");
		}
		else
		{
			if(!name.matches("[A-Z][A-Za-z]{2,}"))
			{
				
				throw new WalletException("Name should start with capital letter and should be atleast 3");
			}			
		}
		return true;
	}
	
	
	
	private boolean validateAge(String age) throws WalletException
	{
		if(age==null || age.isEmpty())
		{
			throw new WalletException("Age cannot be Empty or Null");
		}
		else
		{
		try
		{
			if(Integer.parseInt(age)<0)
			{
			
				throw new WalletException("Age cannot be Zero");
			}
		}
		catch(Exception e)
		{
			 throw new WalletException("Age should be Numeric");
		}
		return true;
		}
	}
	
	
	
	
	/*private boolean validateAddress(String add) throws WalletException
	{
		if(add==null || add.isEmpty())
		{
			throw new WalletException("You have to provide address as it cannot be empty");
		}
		else
		{
			if(!add.matches("[A-Za-z0-9][A-Za-z0-9]{2,}"))
			{
				throw new WalletException("Enter a Valid Address");
			}
		}
		return true;
	}*/
	
	
	private boolean validatePhoneNo (String phoneNo) throws WalletException 
	{
		if(phoneNo==null || phoneNo.isEmpty())
		{
			throw new WalletException("Enter a  Valid Number as it cannot be Empty");
		}
		else
		{
			if(!phoneNo.matches("\\d{10}"))
			{
				throw new WalletException("The mobile number should be 10 digit");
			}
		}
		return true;
	}
	
	
	
	private boolean validateAccType(String type) throws WalletException
	{
		if(type==null || type.isEmpty())
		{
			throw new WalletException("Account type cannot be Null or Empty");
		}
		else
		{
			if(type.toLowerCase().equalsIgnoreCase("savings")!=true && type.toLowerCase().equalsIgnoreCase("current")!=true)
			{
				
				throw new WalletException("Enter a valid account type either savings or current");
			}			
		}
		return true;
	}
	private boolean validateInitBalance(String balance) throws WalletException
	{
		if(balance==null || balance.isEmpty())
		{
			throw new WalletException("Balance cannot be Empty or Null");
		}
		else
		{
		try
		{
			if(Double.parseDouble(balance)<0)
			{
			
				throw new WalletException("Balance cannot be Negative");
			}
		}
		catch(WalletException e)
		{
			 throw new WalletException("Balance should be Numeric");
		}
		return true;
		}
	}
	
	

	@Override
	public String createAccount(Customer cnew, Account ac) throws WalletException
	{
		return idao.createAccount(cnew,ac);
	}

	@Override
	public String showBalance(String acc_no) throws WalletException {
		
		return idao.showBalance(acc_no);
	}

	@Override
	public String depositBalance(String dep_acc_no, String amount) throws WalletException {
		try
		{
			double amt=Double.parseDouble(amount);
			if(amt<0)
			{
				throw new WalletException("Enter a amount that is greater than 0");
			}
		}
			catch(WalletException e)
			{
				throw new WalletException(e.getMessage());
			}
		return idao.depositBalance(dep_acc_no, amount);
	}

	@Override
	public String withdrawBalance(String withdraw_acc_no, String amount) throws WalletException {
		try
		{
			double amt=Double.parseDouble(amount);
			if(amt<0)
			{
				throw new WalletException("Enter a amount that is greater than 0");
			}
			else
			{
				String bal=showBalance(withdraw_acc_no);
				if(bal!=null)
				{
				if(amt>Double.parseDouble(bal))
				{
					throw new WalletException("Withdrawal not possible as balance is low");
				}
				else
				{
					return idao.withdrawBalance(withdraw_acc_no, amount);
				}
				}
				else
				{
					throw new WalletException("Sender account doesnot exists");
				}
			}
		}
			catch(WalletException e)
			{
				throw new WalletException(e.getMessage());
			}
	}

	@Override
	public String fundTransfer(String origin_acc_no,String dest_acc_no,String amt) throws WalletException {
		
		boolean sender = idao.checkAccountExist(origin_acc_no);
		boolean receiver = idao.checkAccountExist(dest_acc_no);
		
		if(sender == false) {
			throw new WalletException("Sender account doesn't exists.");
		}
		else if(receiver == false) {
			throw new WalletException("Receiver account doesn't exists.");
		}
		
		try {
			if(origin_acc_no.equals(dest_acc_no)) {
				throw new WalletException("Invalid transaction! Both account numbers same.");
			}
			Double amount = Double.parseDouble(amt);
			if(amount<0) {
				throw new WalletException("Amount cannot be less than 0");
			}
			if(amount > Double.parseDouble(idao.showBalance(origin_acc_no))) {
				throw new WalletException("Insufficient balance in the account to complete this transaction.");
			}
			else {
				return idao.fundTransfer(origin_acc_no, dest_acc_no, amt);
			}
		} catch (WalletException e) {
			throw new WalletException(e.getMessage());
		}
		catch (Exception ex) {
			throw new WalletException("Enter only numerical");
		}
	 
	}

	@Override
	public boolean checkAccountExist(String acc) throws WalletException {
		return idao.checkAccountExist(acc);
	}

	@Override
	public String updateDW(String status, String account, String amount, LocalDate date, String transaction_type)
			throws WalletException {
	
		return idao.updateDW(status, account, amount, date, transaction_type);
	}

	@Override
	public String transferTransaction(String status, String sender_account, String receiver_account, String amount,
			LocalDate date, String transaction_type) throws WalletException {
		
		return idao.transferTransaction(status, sender_account, receiver_account, amount, date, transaction_type);
	}

	@Override
	public HashMap<String, Transaction> printingTransaction(String accno) throws WalletException {
		return idao.printingTransaction(accno);
	}

	

}
		






