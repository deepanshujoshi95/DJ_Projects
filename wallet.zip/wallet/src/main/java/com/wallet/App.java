package com.wallet;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.service.CustomerServiceImpl;
import com.wallet.service.ICustomerService;
import com.wallet.walletException.WalletException;

public class App 
{
	ICustomerService iservice= new CustomerServiceImpl();
	Scanner sc= new Scanner(System.in);
    public static void main( String[] args )
    {
    	App a=new App();
    	String option;
    	while(true)
    		{	System.out.println();
    			System.out.println("  "+"*****************************WELCOME*****************************");
    			System.out.println("  "+"*                                                               *");
    			System.out.println("  "+"*              ==========HDFC BANK WALLET APP==========         *");
    			System.out.println("  "+"*                        1: Create Account                      *");
    			System.out.println("  "+"*                        2: Show Balance                        *");
    			System.out.println("  "+"*                        3: Deposit Amount                      *");
    			System.out.println("  "+"*                        4: Withdraw Amount                     *");
    			System.out.println("  "+"*                        5: Fund Transfer                       *");
    			System.out.println("  "+"*                        6: Print Transaction                   *"); 
    			System.out.println("  "+"*                        7: Exit                                *");
    			System.out.println("  "+"*                                                               *");
    			System.out.println("  "+"*****************************WELCOME*****************************");
    			System.out.println("Enter your Choice from 1 to 7");
    			option=a.sc.nextLine();
    	
    			switch(option)
    			{
    			case "1":
    				a.createAccount();
    				break;
    			case "2":
    				a.showBalance();
    				break;
    			case "3":
    				a.depositAmount();
    				break;
    			case "4":
    				a.withdrawAmount();
    				break;
    			case "5":
    				a.fundTransfer();
    				break;
    			case "6":
    				a.printTransaction();
    				break;
    			case "7":
    				System.out.println("THANKYOU FOR BANKING!! Keep Visiting");
    				System.exit(0);
     			default:
    				System.err.println("Choose a Valid Option");
    				break;
    			}
    	
    		}       
    }
   
    
    public void createAccount()
    {
      Customer cnew= new Customer();
      Account ac= new Account();
	  System.out.println("Enter Name");
	  cnew.setCust_name(sc.nextLine());
	  System.out.println("Enter your Age");
	  cnew.setCust_age(sc.nextLine());
	  System.out.println("Enter your address");
	  cnew.setCust_address(sc.nextLine());
	  System.out.println("Enter your Phone Number");
	  cnew.setPhoneno(sc.nextLine());
	  System.out.println("Enter the Account Type");
	  ac.setAcc_type(sc.nextLine());
	  System.out.println("Enter the initial opening Balance");
	  ac.setAcc_balance(sc.nextLine());
	  try {
		boolean check =iservice.validateData(cnew,ac);
		if(check)
		{
			String newAccNo=iservice.createAccount(cnew,ac);
			if(newAccNo!=null)
			{
				System.out.println("Account with account number "+ newAccNo +" created Successfully");
				String transId=iservice.updateDW("Success", newAccNo, ac.getAcc_balance(), LocalDate.now(), "deposit");	
				System.out.println("Transaction ID is "+transId);
			}
			else
				System.err.println("Couldn't create account!! Sorry!");
		}
	} catch (WalletException e) {

		System.err.println(e.getMessage());
	
	}
		catch (Exception ex)
  	{
			
			System.err.println(ex.getMessage());
		
  	}
    }
  
    public void showBalance()
    {
	  System.out.println("Enter the account number");
	  String acc=sc.nextLine();
	  try {
		String result= iservice.showBalance(acc);
		if(result==null)
		{
			System.err.println("Account number doesnot exist");
		}
		else
		{
			System.out.println();
			System.out.println("The balance for account no "+ acc +" is " +result);
			System.out.println();
		}
	} catch (WalletException e) {
	
		System.err.println(e.getMessage());

	}
		catch (Exception ex)
  	{
		
			System.err.println(ex.getMessage());
		
  	}
    }
    
    public void depositAmount()
    {
	  System.out.println("Enter the account number you want to deposit money in ");
	  String dep_acc_no=sc.nextLine();
	  System.out.println("Enter the Number amount you want to deposit");
	  String amount= sc.nextLine();
	  try {
		String totalAmount=iservice.depositBalance(dep_acc_no,amount);
		if(totalAmount!=null)
		{
			System.out.println("The new balance is "+ totalAmount);
			String transId=iservice.updateDW("Success", dep_acc_no, amount, LocalDate.now(), "deposit");	
			System.out.println("Transaction ID is "+transId);
		}
		else
		{
		System.err.println("Account not found for given credentials");
		}
	} catch (WalletException e) {
	
		System.err.println(e.getMessage());

	}
		catch (Exception ex)
  	{
		
			System.err.println(ex.getMessage());

  	}
    }
  
    public void withdrawAmount()
    {
	  System.out.println("Enter the account number you want to withdraw money in ");
	  String withdraw_acc_no=sc.nextLine();
	  System.out.println("Enter the Number amount you want to wihdraw");
	  String amount= sc.nextLine();
	  try {
		String totalAmount=iservice.withdrawBalance(withdraw_acc_no,amount);
		if(totalAmount!=null)
		{
			System.out.println("The new balance is "+ totalAmount);
			String transId=iservice.updateDW("Success", withdraw_acc_no, amount, LocalDate.now(), "withdraw");	
			System.out.println("Transaction ID is "+transId);
		}
		else
		{
		System.err.println("Account not found for given credentials");
		}
	} catch (WalletException e) {

		System.err.println(e.getMessage());
	
	}
		catch (Exception ex)
  	{
	
			System.err.println(ex.getMessage());
		
  	}
    }
    
    
    public void fundTransfer()
    {
    	System.out.println("Enter your account number");
    	String origin_acc_no=sc.nextLine();
    	System.out.println("Enter the account number in which you want to transfer money");
    	String dest_acc_no=sc.nextLine();
    	System.out.println("Enter the amount you want to transfer");
    	String amount =sc.nextLine();
    	try {
			String balance=iservice.fundTransfer(origin_acc_no,dest_acc_no,amount);
			if(balance!=null)
			{
				System.out.println(" Transfer Successful. Amount of Rs. "+ amount +" has been transferred from your account. "+
					origin_acc_no+ " to account number "+ dest_acc_no +" Your new balance is " +balance);
				
				String transId= iservice.transferTransaction("success", origin_acc_no, dest_acc_no, amount, LocalDate.now(), "transfer");
				System.out.println("Transaction ID is "+transId);
			}
			else
			{
				System.out.println("Account not found for given credentials");
			}
		} 
    	catch (WalletException e)
    	{
			System.err.println(e.getMessage());
    	}
    	catch (Exception ex)
    	{
			System.err.println(ex.getMessage());
    	}

    }
    
    
    public void printTransaction() {
    	System.out.println("Enter account number: ");
    	String acc = sc.nextLine();
    	
    	try {
			  boolean check = iservice.checkAccountExist(acc);
			  if(check == true) {
				  System.out.println("Transaction History\n*************************************"); 
				  
				  HashMap<String,Transaction> tMap = iservice.printingTransaction(acc);
				  
				  if(tMap.size() == 0) {
					  System.out.println("No transaction available");
				  }
				  else {
				    for(Map.Entry<String, Transaction> entry: tMap.entrySet()) {
					 
				      System.out.println("Transaction ID         : "+ entry.getKey().toString());
					  System.out.println("Status                 : "+ entry.getValue().getStatus().toString());
					  System.out.println("Type                   : "+ entry.getValue().getTransaction_type().toString());
					  System.out.println("Amount                 : "+ entry.getValue().getAmount().toString());
					 if(entry.getValue().getTransaction_type().toString().equals("transfer")) {
					  System.out.println("Sender Account number  : "+ entry.getValue().getSender_account().toString());
					  System.out.println("Receiver Account number: "+ entry.getValue().getReceiver_account().toString());
				   }
					 else {
					  System.out.println("Account number         : "+ entry.getValue().getAccount().toString());
					 }
					 System.out.println("*************************************");
					 }
				  }
			  }
			  else {
				  System.err.println("Account number doesn't exists.");
			  }
		} catch (WalletException e) {
			System.err.println(e.getMessage());
		}
        }
    
    
    
    
}
