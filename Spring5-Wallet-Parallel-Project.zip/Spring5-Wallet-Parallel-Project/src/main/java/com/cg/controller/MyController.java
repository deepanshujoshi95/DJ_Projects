package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class MyController
{		@RequestMapping("/validatelogin")
		public String validateLogin(ModelMap map,@RequestParam("username") String uname, @RequestParam("password")String passwd)
		{
			if(uname.equals("admin") && passwd.equals("1234"))
			{
				return "walletmenu";
			}
		return "redirect:/";
		}

		@RequestMapping("/createaccount")
		public String showcreateAccountPage()
		{
			return "createaccount";
		}
		
		@RequestMapping("/showbalance")
		public String showBalPage()
		{
			return "showbalance";
		}
		
		
		@RequestMapping("/deposit")
		public String deposit()
		{
			return "deposit";
			
		}
		
		
			
}