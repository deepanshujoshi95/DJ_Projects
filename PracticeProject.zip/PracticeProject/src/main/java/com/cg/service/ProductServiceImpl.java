package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IProductDao;
import com.cg.model.ProductDetails;

@Service("pservice")
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private IProductDao pdao;
	@Override
	public List<ProductDetails> getProducts() {
		
		return pdao.getProducts();
	}
	@Override
	public ProductDetails findProduct(String id) {

		return pdao.findProduct(id);
	}
	@Override
	public void updateProduct(ProductDetails product2) {
		
		 pdao.updateProduct(product2);
		
		
	}

}
