package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.ProductDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.service.IProductService;
@Controller
public class ProdController {
	
	@Autowired
	private IProductService pservice;
	
	private ProductDetails productrec;
	
	@RequestMapping("/")
	public String showProduct(ModelMap map)
	{	
		List<ProductDetails> products=pservice.getProducts();
		map.put("p1", products);
		return "Product";
	}
	@RequestMapping("/update/{id}")
	public String findProduct(ModelMap map,@PathVariable("id") Integer id)
	{	
		productrec=pservice.findProduct(id);
		map.put("p2", productrec);
		return "updateProduct";
	}
	@RequestMapping("/updateProduct")
	public String updateProduct(ModelMap map,@ModelAttribute("product") ProductDetails product1)
	{
		List<String> category=new ArrayList<>();
		category.add("Electronics");
		category.add("Home");
		category.add("Daily use");	
		map.put("categories", category);
		return "Product";
	}	
	
	@PostMapping("/saveProduct")
	public String saveProduct(@ModelAttribute("productss") ProductDetails product2)
	{
		pservice.updateProduct(product2);
		return "Product";
	}	
	
}