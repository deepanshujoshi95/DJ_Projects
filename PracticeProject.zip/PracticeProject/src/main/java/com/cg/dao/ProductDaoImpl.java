package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.ProductDetails;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("pdao")
public class ProductDaoImpl implements IProductDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	@Transactional
	public List<ProductDetails> getProducts() {
		List<ProductDetails> products =entityManager.createQuery("from ProductDetails").getResultList();
		return products;
	}
	@Override
	@Transactional
	public ProductDetails findProduct(Integer id) {
		
		ProductDetails productrec=entityManager.find(ProductDetails.class, id);
		return productrec;
	}
	@Transactional
	@Override
	public void updateProduct(ProductDetails product1) {
		
		entityManager.merge(product1);

	}

}
