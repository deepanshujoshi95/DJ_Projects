package com.cg.dao;

import java.util.List;

import com.cg.model.ProductDetails;

public interface IProductDao {

	public List<ProductDetails> getProducts();

	public ProductDetails findProduct(String id);

	public void updateProduct(ProductDetails product2);

}
