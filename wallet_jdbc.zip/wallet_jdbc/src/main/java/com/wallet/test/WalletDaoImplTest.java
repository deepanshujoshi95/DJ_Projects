package com.wallet.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.bean.CustomerId;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {

	WalletDao wDao = new WalletDaoImpl();
	
	
	@Test
	public void testCreateAccount() throws WalletException {
	  //String s = wDao.createAccount(new Customer("Virat","Delhi","31","8574915365","iamVirat"), new Account("current","85000.50"));
	  //assertEquals("85000.50", wDao.showBalance(s));
		
	}

	@Test
	public void testShowBalance() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeposit() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTransaction() {
		fail("Not yet implemented");
	}

}
