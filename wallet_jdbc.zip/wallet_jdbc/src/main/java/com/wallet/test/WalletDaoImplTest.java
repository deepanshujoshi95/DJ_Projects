package com.wallet.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import org.junit.Test;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {

	WalletDao wDao = new WalletDaoImpl();
	
	@Test
	public void testCreateAccount() throws WalletException {
	  
		String account1 = wDao.createAccount(new Customer("Deepanshu","Delhi","24","8955539814","iamDJ"), new Account("current","60000"));
		String account2 = wDao.createAccount(new Customer("Raj","Chennai","29","9667854633","raj154"), new Account("savings","5000"));
		
		
	    assertEquals(true,wDao.checkAccountExist(account1));
	    assertEquals(true,wDao.checkAccountExist(account2));
		
	}

	@Test
	public void testShowBalance() throws WalletException {
		
		String account1 = wDao.createAccount(new Customer("Jaspreet","Rajasthan","26","8881475698","singh"), new Account("current","6500"));
		assertEquals("6500", wDao.showBalance(account1));
		
	}

	@Test
	public void testDeposit() throws WalletException {
		
		String account1 = wDao.createAccount(new Customer("Swadeep","Kolkata","30","9954768526","rajput"), new Account("savings","7500.25"));
		
		assertEquals("7500.25", wDao.showBalance(account1));
		
		String newBalance = wDao.deposit(account1, "1000");
		
		assertEquals(newBalance, wDao.showBalance(account1));
	}

	@Test
	public void testWithdraw() throws WalletException {
		String account1 = wDao.createAccount(new Customer("Deep","Sikar","22","9566741357","choudhary"), new Account("current","35000.75"));
		
		assertEquals("35000.75", wDao.showBalance(account1));
		
		String newBalance = wDao.withdraw(account1, "20000.00");
		
		assertEquals(newBalance, wDao.showBalance(account1));
	}

	@Test
	public void testFundTransfer() throws WalletException {
		
		String account1 = wDao.createAccount(new Customer("Jaspreet","Rajasthan","26","8881475698","singh"), new Account("current","6500.50"));
		String account2 = wDao.createAccount(new Customer("Swadeep","Kolkata","30","9954768526","rajput"), new Account("savings","8000.75"));
		
		
	    assertEquals(true,wDao.checkAccountExist(account1));
	    assertEquals(true,wDao.checkAccountExist(account2));
	    
	    String senderBalance = wDao.fundTransfer(account1, "500", account2);
	    
	    assertEquals(senderBalance, wDao.showBalance(account1));
	    assertEquals("8500.75", wDao.showBalance(account2));
	}

	@Test
	public void testPrintTransaction() throws WalletException {
		
		String account1 = wDao.createAccount(new Customer("Jaspreet","Rajasthan","26","8881475698","singh"), new Account("current","7000.50"));
		String account2 = wDao.createAccount(new Customer("Swadeep","Kolkata","30","9954768526","rajput"), new Account("savings","7500.50"));
	
		String newBalance = wDao.deposit(account1, "500");
		wDao.transaction("deposit", LocalDate.now(), account1, account1, "success","500");
		
		assertEquals(newBalance, wDao.showBalance(account1));
		
		String senderBalance = wDao.fundTransfer(account1, "1000", account2);
		wDao.transaction("transfer", LocalDate.now(), account1, account2, "success","1000");
		
		assertEquals(senderBalance, wDao.showBalance(account1));
	    
	    assertEquals(1,wDao.printTransaction(account1).size());
	    assertEquals(0,wDao.printTransaction(account2).size());
	}

}
