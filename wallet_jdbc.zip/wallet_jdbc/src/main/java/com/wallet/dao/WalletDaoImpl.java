package com.wallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.wallet.exception.*;
import com.wallet.bean.Account;
import com.wallet.bean.AccountNumber;
import com.wallet.bean.Customer;
import com.wallet.bean.CustomerId;
import com.wallet.bean.Transaction;
import com.wallet.bean.TransactionId;
import com.wallet.exception.WalletException;
import com.wallet.util.DBConnection;

public class WalletDaoImpl implements WalletDao {

Logger logger=Logger.getRootLogger();
	
	
	public WalletDaoImpl() {
		
		PropertyConfigurator.configure("resources//log4j.properties");
	}


	@Override
	public String createAccount(Customer c, Account a) throws WalletException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		Connection conn1 = DBConnection.getInstance().getConnection();
		
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		
		int qResult = 0;
		int qResult1 = 0;
		
		try {
			   ps = conn.prepareStatement(QueryMapper.INSERT_CUSTOMER);
			   
			   CustomerId cId = new CustomerId();
			   
			   ps.setString(1, cId.getCustomer_id());
			   ps.setString(2, c.getCustomer_name());
			   ps.setString(3, c.getCustomer_address());
			   ps.setString(4, c.getCustomer_age());
			   ps.setString(5, c.getCustomer_phone());
			   ps.setString(6, c.getCustomer_password());
			   
			   qResult = ps.executeUpdate();
			   
			 if(qResult == 0) {
				 conn.rollback();
				 throw new WalletException("Error in writing to database. Rolling back.");
			 }
			 else {
				  ps1 = conn1.prepareStatement(QueryMapper.INSERT_ACCOUNT);
				  
				  AccountNumber aNum = new AccountNumber();
				  
				  ps1.setString(1, aNum.getAccount_Number());
				  ps1.setString(2, cId.getCustomer_id());
				  ps1.setFloat(3, Float.valueOf(a.getAccount_balance()));
				  ps1.setString(4, a.getAccount_type());
				  
				 qResult1 = ps1.executeUpdate();
			   
				if(qResult1 == 0) {
					conn.rollback();
					conn1.rollback();
					throw new WalletException("Error in writing to database. Rolling back.");
				}
				else {
					return aNum.getAccount_Number();
				}
			 }
			
		} catch (SQLException e) {
			throw new WalletException("Error :" + e.getMessage());
		}
		finally {
			      try {
					ps.close();
					ps1.close();
					
					conn.commit();
					conn1.commit();
					
					conn.close();
					conn1.close();
				} catch (SQLException e) {
					throw new WalletException("Error in closing the resources.");
				}
		}
		
	
	}


	@Override
	public String showBalance(String accNumber) throws WalletException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			 ps = conn.prepareStatement(QueryMapper.GET_BALANCE);
			 ps.setString(1, accNumber);
			 rs = ps.executeQuery();
			 
			 if(rs.next()) {
				 return rs.getString(1).toString();
			 }
			 else {
				 throw new WalletException("Database reading error.");
			 }
		}catch (SQLException e) {
			throw new WalletException("Error in database");
		}finally {
			try {
				 rs.close();
				 ps.close();
				 conn.close();
			} catch (SQLException e2) {
				throw new WalletException("Error in closing Resources.");
			}
			
		}
	}


	@Override
	public String deposit(String acc, String amt) throws WalletException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		Connection conn1 = DBConnection.getInstance().getConnection();
		
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		
		int qResult = 0;
		ResultSet rs = null;
		Float balance = 0f;
		
		try {
			  ps = conn.prepareStatement(QueryMapper.GET_BALANCE);
			  ps.setString(1, acc);
			  rs = ps.executeQuery();
			  
			if(rs.next()) {
				balance = rs.getFloat(1);
				balance+= Float.valueOf(amt);
				
				ps1 = conn1.prepareStatement(QueryMapper.UPDATE_BALANCE);
				ps1.setFloat(1, balance);
				ps1.setString(2, acc);
				
				qResult = ps1.executeUpdate();
			  
			  if(qResult == 0) {
				  throw new WalletException("Updation error");
			  }
			  else {
				  return balance.toString();
			  }
			 }
			else {
				throw new WalletException("Deposit failed");
			}
		} catch (SQLException e) {
			throw new WalletException("Error in database.");
		}
		finally {
			try {
				 rs.close();
				 ps1.close();
				 ps.close();
				 conn1.close();
				 conn.close();
			}
			catch (SQLException e) {
				throw new WalletException("Error in closing resources.");
			}
		}
	}


	@Override
	public String withdraw(String acc, String amt) throws WalletException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		Connection conn1 = DBConnection.getInstance().getConnection();
		
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		
		int qResult = 0;
		ResultSet rs = null;
		Float balance = 0f;
		
		try {
			  ps = conn.prepareStatement(QueryMapper.GET_BALANCE);
			  ps.setString(1, acc);
			  rs = ps.executeQuery();
			  
			if(rs.next()) {
				balance = rs.getFloat(1);
				balance-= Float.valueOf(amt);
				
				ps1 = conn1.prepareStatement(QueryMapper.UPDATE_BALANCE);
				ps1.setFloat(1, balance);
				ps1.setString(2, acc);
				
				qResult = ps1.executeUpdate();
			  
			  if(qResult == 0) {
				  throw new WalletException("Updation error");
			  }
			  else {
				  return balance.toString();
			  }
			 }
			else {
				throw new WalletException("Deposit failed");
			}
		} catch (SQLException e) {
			throw new WalletException("Error in database.");
		}
		finally {
			try {
				 rs.close();
				 ps1.close();
				 ps.close();
				 conn1.close();
				 conn.close();
			}
			catch (SQLException e) {
				throw new WalletException("Error in closing resources.");
			}
		}
	}


	@Override
	public boolean checkAccountExist(String acc) throws WalletException {

		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			  ps = conn.prepareStatement(QueryMapper.CHECK_ACCOUNT);
			  ps.setString(1, acc);
			  rs = ps.executeQuery();
			  
			 if(rs.next()) {
				 return true;
			 }
			 else {
				 return false;
			 }
		} catch (SQLException e) {
			throw new WalletException("Database connection error.");
		}
		finally {
			try {
				  rs.close();
				  ps.close();
				  conn.close();
			} catch (SQLException e2) {
				throw new WalletException("Error in closing resourcse.");
			}
		}
		
	
	}


	@Override
	public String fundTransfer(String acc, String amt, String rAcc) throws WalletException {
		
		Connection conn  = DBConnection.getInstance().getConnection();
		Connection conn1 = DBConnection.getInstance().getConnection();
		
		PreparedStatement ps =null;
		PreparedStatement ps1 = null;
		
		PreparedStatement ps2 = null;
		PreparedStatement ps3 = null;
		
		ResultSet rs = null;
		ResultSet rs1 = null;
		
		Float sBalance = 0f;
		Float rBalance = 0f;
		
		Float sNew = 0f;
		Float rNew = 0f;
		
		int qResult  = 0;
		int qResult1 = 0;
		
		try {
			 ps = conn.prepareStatement(QueryMapper.GET_BALANCE);
			 ps.setString(1, acc);
			 
			 rs = ps.executeQuery();
			 
			if(rs.next()) {
				sBalance = rs.getFloat(1);
				
				ps1 = conn1.prepareStatement(QueryMapper.GET_BALANCE);
				ps1.setString(1, rAcc);
				
				rs1 = ps1.executeQuery();
				
			 if(rs1.next()) {
				rBalance = rs1.getFloat(1);
				
				sNew = sBalance - Float.valueOf(amt);
				rNew = rBalance + Float.valueOf(amt);
				
				ps2 = conn.prepareStatement(QueryMapper.UPDATE_BALANCE);
				ps2.setFloat(1, sNew);
				ps2.setString(2, acc);
				
				qResult = ps2.executeUpdate();
				
				ps3 = conn1.prepareStatement(QueryMapper.UPDATE_BALANCE);
				ps3.setFloat(1, rNew);
				ps3.setString(2, rAcc);
				
				qResult1 = ps3.executeUpdate();
			 
				if(qResult==1 && qResult1==1) {
					conn.commit();
					conn1.commit();
				  return Float.toString(sNew);
				}
				else {
					conn.rollback();
					conn1.rollback();
				throw new WalletException("Error in transaction. Rolling back");
				}
			 }
			 else {
				 throw new WalletException("Error in transaferring.");
			 }
				
			}
			else {
				throw new WalletException("Error in transaferring.");
			}
		} catch (SQLException e) {
			throw new WalletException("Error in database.");
		}
		finally {
			try {
				  rs1.close();
				  rs.close();
				  
				  ps3.close();
				  ps2.close();
				  ps1.close();
				  ps.close();
				  
				  conn1.close();
				  conn.close();
			} catch (SQLException e2) {
				throw new WalletException("Error in closing resources.");
			}
		}
		
	}


	@Override
	public String transaction(String transaction_type, LocalDate transaction_date, String transaction_sender,
			String transaction_receiver, String transaction_status, String transaction_amount) throws WalletException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;
		int qResult = 0;
		
		try {
			  ps = conn.prepareStatement(QueryMapper.INSERT_TRANSACTION);
			  TransactionId tId = new TransactionId();
			  
			  ps.setString(1, tId.getTransaction_Number());
			  ps.setString(2, transaction_type);
			  ps.setString(3, transaction_date.toString());
			  ps.setString(4, transaction_sender);
			  ps.setString(5, transaction_receiver);
			  ps.setString(6, transaction_status);
			  ps.setFloat(7, Float.valueOf(transaction_amount));
			  
			  qResult = ps.executeUpdate();
			  
			if(qResult == 0) {
				conn.rollback();
				throw new WalletException("Error in transaction. Rolling back.");
			}
			else {
				conn.commit();
				return tId.getTransaction_Number();
			}
		} catch (SQLException e) {
			throw new WalletException("Error in database.");
		}
		finally {
			try {
				 ps.close();
				 conn.close();
			} catch (SQLException e2) {
				throw new WalletException("Error in closing the resources.");
			}
		}
		
		
		
	}


	

	@Override
	public HashMap<String, Transaction> printTransaction(String acc) throws WalletException {
		
		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		HashMap<String, Transaction> H = new HashMap<String, Transaction>();
		
		try {
			  ps = conn.prepareStatement(QueryMapper.GET_TRANSACTIONS);
			  
			  ps.setString(1, acc);
			  ps.setString(2, acc);
			  
			  rs = ps.executeQuery();
			  
			if(rs.next()) {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				
				while(rs.next()) {
				H.put(rs.getString(1), new Transaction(rs.getString("transaction_status"), rs.getString("transaction_type"), rs.getString("sender_account_number"),
						rs.getString("receiver_account_number"), LocalDate.parse(rs.getString("transaction_date"), formatter), Float.toString(rs.getFloat("transaction_amount")) ));
				}
			 return H;
			}
			else {
				throw new WalletException("No transactions found.");
			}
		} catch (SQLException e) {
			throw new WalletException("Error in SQL connection.");
		}
		finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e2) {
			     throw new WalletException("Error in closing resources.");
			}
		}
	}


	
	@Override
	public boolean checkAccountPassword(String acc, String pass) throws WalletException {
		Connection conn = DBConnection.getInstance().getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			  ps = conn.prepareStatement(QueryMapper.CHECK_PASSWORD);
			  ps.setString(1, pass);
			  ps.setString(2, acc);
			  
			 try { 
			 rs = ps.executeQuery();
			  
			 if(!rs.next()) {
				 return false;
			 }
			 else {
				 return true;
			 }
		}catch (NullPointerException n) {
			return false;
		}
	   }
		 catch (SQLException e) {
			
				throw new WalletException("Error in database connection.");
			
		}
		finally {
			try {
				  ps.close();
				  conn.close();
			} catch (SQLException e2) {
				throw new WalletException("Error in closing the resources.");
			}
		}
	}

	
	

}
